import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'YoYo Map — DMV Throwers',
  description: 'A privacy-first community map to help yo-yoers find each other. Opt-in, city-level only, always deletable.',
  openGraph: {
    title: 'YoYo Map',
    description: 'Find fellow yo-yoers in your area. Built by DMV Throwers.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        <header className="bg-navy text-cream border-b-4 border-brand-red">
          <nav className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between flex-wrap gap-4">
            <Link href="/" className="font-display text-2xl tracking-tight">
              YoYo <span className="text-brand-red">Map</span>
            </Link>
            <ul className="flex gap-6 text-xs uppercase font-semibold tracking-wider">
              <li><Link href="/map" className="hover:text-brand-red transition-colors">Map</Link></li>
              <li><Link href="/submit" className="hover:text-brand-red transition-colors">Add Me</Link></li>
              <li><Link href="/profile" className="hover:text-brand-red transition-colors">My Entry</Link></li>
              <li><Link href="/legal/privacy" className="hover:text-brand-red transition-colors">Privacy</Link></li>
            </ul>
          </nav>
        </header>

        <main className="flex-1">{children}</main>

        <footer className="bg-dark-navy text-cream/80 border-t-4 border-brand-red mt-12">
          <div className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <p className="font-display text-lg text-cream">YoYo Map</p>
              <p className="mt-2">A community project of DMV Throwers Yo-Yo &amp; Skill Toy Club. All skill levels welcome.</p>
            </div>
            <div>
              <p className="font-semibold uppercase tracking-wider text-xs mb-2">Legal</p>
              <ul className="space-y-1">
                <li><Link href="/legal/privacy" className="hover:text-brand-red">Privacy Policy</Link></li>
                <li><Link href="/legal/terms" className="hover:text-brand-red">Terms of Service</Link></li>
              </ul>
            </div>
            <div>
              <p className="font-semibold uppercase tracking-wider text-xs mb-2">Contact</p>
              <p>dmvthrowers@gmail.com</p>
              <p className="mt-2 text-xs">DC · MD · VA</p>
            </div>
          </div>
          <div className="bg-navy py-3 text-center text-xs">
            <p>© {new Date().getFullYear()} DMV Throwers · EIN 41-4879324</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
