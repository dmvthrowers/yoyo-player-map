'use client';

import { useState } from 'react';
import Link from 'next/link';

interface FormState {
  displayName: string;
  email: string;
  city: string;
  region: string;
  country: string;
  bio: string;
  ageBand: '' | '13-17' | '18+';
  instagram: string;
  youtube: string;
  discord: string;
  website: string;
  parentName: string;
  parentEmail: string;
  relationship: '' | 'parent' | 'legal guardian';
  consentPrivacy: boolean;
  consentTerms: boolean;
  consentPublic: boolean;
  honeypot: string;
}

const initial: FormState = {
  displayName: '',
  email: '',
  city: '',
  region: '',
  country: 'US',
  bio: '',
  ageBand: '',
  instagram: '',
  youtube: '',
  discord: '',
  website: '',
  parentName: '',
  parentEmail: '',
  relationship: '',
  consentPrivacy: false,
  consentTerms: false,
  consentPublic: false,
  honeypot: '',
};

export default function SubmitPage() {
  const [form, setForm] = useState<FormState>(initial);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<null | { ok: boolean; message: string; isMinor?: boolean }>(null);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  const isMinor = form.ageBand === '13-17';

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setResult(null);

    const payload = {
      displayName: form.displayName,
      email: form.email,
      city: form.city,
      region: form.region || undefined,
      country: form.country,
      bio: form.bio || undefined,
      ageBand: form.ageBand,
      socials: {
        instagram: form.instagram || undefined,
        youtube: form.youtube || undefined,
        discord: form.discord || undefined,
        website: form.website || undefined,
      },
      parentName: form.parentName || undefined,
      parentEmail: form.parentEmail || undefined,
      relationship: form.relationship || undefined,
      consentPrivacy: form.consentPrivacy,
      consentTerms: form.consentTerms,
      consentPublic: form.consentPublic,
      honeypot: form.honeypot,
    };

    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setResult({ ok: false, message: data.error || 'Something went wrong. Please try again.' });
      } else {
        setResult({ ok: true, message: data.message, isMinor });
      }
    } catch {
      setResult({ ok: false, message: 'Network error. Please try again.' });
    } finally {
      setSubmitting(false);
    }
  }

  if (result?.ok) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16">
        <div className="card text-center">
          <h1 className="text-3xl mb-4">Check your email</h1>
          <p className="text-navy/80 mb-4">{result.message}</p>
          {result.isMinor && (
            <p className="text-sm bg-cherry-pink p-4 border-2 border-brand-red/30">
              We also sent a consent request to your parent or guardian. Your entry will appear on the map once they confirm.
            </p>
          )}
          <Link href="/" className="btn-ghost mt-6 inline-block">Back to home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="mb-8">
        <p className="text-xs uppercase tracking-[0.3em] text-brand-red font-bold mb-2">Add Yourself</p>
        <h1 className="text-4xl md:text-5xl mb-2">Join the Map</h1>
        <p className="text-navy/80">
          Takes under a minute. Your city-level location will be blurred to a ~10 mile radius.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-6">
        {/* Honeypot — hidden from humans, bots will fill it */}
        <div className="hidden" aria-hidden="true">
          <label>Do not fill this field</label>
          <input
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={form.honeypot}
            onChange={(e) => update('honeypot', e.target.value)}
          />
        </div>

        <div className="card space-y-4">
          <h2 className="text-2xl">About you</h2>

          <div>
            <label className="label">Display name *</label>
            <input
              className="input"
              required
              maxLength={40}
              value={form.displayName}
              onChange={(e) => update('displayName', e.target.value)}
              placeholder="e.g. CaptnRogers"
            />
            <p className="text-xs text-navy/60 mt-1">Shown publicly. Use a handle, not your real name if you prefer.</p>
          </div>

          <div>
            <label className="label">Email *</label>
            <input
              className="input"
              type="email"
              required
              value={form.email}
              onChange={(e) => update('email', e.target.value)}
            />
            <p className="text-xs text-navy/60 mt-1">Never shown publicly. Used only to verify and let you edit later.</p>
          </div>

          <div>
            <label className="label">Age *</label>
            <div className="flex gap-3">
              <label className="flex items-center gap-2 flex-1 border-2 border-navy/20 p-3 cursor-pointer hover:border-brand-red">
                <input
                  type="radio"
                  name="ageBand"
                  checked={form.ageBand === '18+'}
                  onChange={() => update('ageBand', '18+')}
                />
                <span className="text-sm font-semibold">18 or older</span>
              </label>
              <label className="flex items-center gap-2 flex-1 border-2 border-navy/20 p-3 cursor-pointer hover:border-brand-red">
                <input
                  type="radio"
                  name="ageBand"
                  checked={form.ageBand === '13-17'}
                  onChange={() => update('ageBand', '13-17')}
                />
                <span className="text-sm font-semibold">13 to 17</span>
              </label>
            </div>
            <p className="text-xs text-navy/60 mt-1">You must be at least 13. Under 18 needs a parent or guardian to consent.</p>
          </div>

          <div>
            <label className="label">Short bio (optional)</label>
            <textarea
              className="input"
              maxLength={280}
              rows={3}
              value={form.bio}
              onChange={(e) => update('bio', e.target.value)}
              placeholder="What do you throw? What brands? Any tricks you're working on?"
            />
            <p className="text-xs text-navy/60 mt-1">{form.bio.length}/280 characters</p>
          </div>
        </div>

        <div className="card space-y-4">
          <h2 className="text-2xl">Where you are</h2>

          <div>
            <label className="label">City or town *</label>
            <input
              className="input"
              required
              value={form.city}
              onChange={(e) => update('city', e.target.value)}
              placeholder="e.g. Dumfries"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">State/region</label>
              <input
                className="input"
                value={form.region}
                onChange={(e) => update('region', e.target.value)}
                placeholder="e.g. VA"
              />
            </div>
            <div>
              <label className="label">Country *</label>
              <input
                className="input"
                required
                maxLength={2}
                value={form.country}
                onChange={(e) => update('country', e.target.value.toUpperCase())}
                placeholder="US"
              />
              <p className="text-xs text-navy/60 mt-1">2-letter code (US, CA, GB, etc.)</p>
            </div>
          </div>
          <p className="text-xs bg-cream border-l-4 border-brand-red p-3">
            We&apos;ll place your pin at the center of your city, then blur it by about 10 miles in a random direction. Your real location is never stored.
          </p>
        </div>

        <div className="card space-y-4">
          <h2 className="text-2xl">Socials (all optional)</h2>
          <p className="text-sm text-navy/70">
            Share whichever handles you want. Just a handle or username — we&apos;ll build the link.
          </p>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Instagram</label>
              <input className="input" value={form.instagram} onChange={(e) => update('instagram', e.target.value)} placeholder="handle" />
            </div>
            <div>
              <label className="label">YouTube</label>
              <input className="input" value={form.youtube} onChange={(e) => update('youtube', e.target.value)} placeholder="channel" />
            </div>
            <div>
              <label className="label">Discord</label>
              <input className="input" value={form.discord} onChange={(e) => update('discord', e.target.value)} placeholder="username" />
            </div>
            <div>
              <label className="label">Website</label>
              <input className="input" value={form.website} onChange={(e) => update('website', e.target.value)} placeholder="https://..." />
            </div>
          </div>
        </div>

        {isMinor && (
          <div className="card space-y-4 bg-cherry-pink border-brand-red">
            <h2 className="text-2xl">Parent or guardian info</h2>
            <p className="text-sm">
              Because you&apos;re under 18, we need your parent or guardian to consent before your entry goes live.
              We&apos;ll email them a link to approve.
            </p>

            <div>
              <label className="label">Parent/guardian full name *</label>
              <input
                className="input"
                required={isMinor}
                value={form.parentName}
                onChange={(e) => update('parentName', e.target.value)}
              />
            </div>
            <div>
              <label className="label">Parent/guardian email *</label>
              <input
                className="input"
                type="email"
                required={isMinor}
                value={form.parentEmail}
                onChange={(e) => update('parentEmail', e.target.value)}
              />
            </div>
            <div>
              <label className="label">Relationship *</label>
              <select
                className="input"
                required={isMinor}
                value={form.relationship}
                onChange={(e) => update('relationship', e.target.value as FormState['relationship'])}
              >
                <option value="">Select…</option>
                <option value="parent">Parent</option>
                <option value="legal guardian">Legal guardian</option>
              </select>
            </div>
          </div>
        )}

        <div className="card space-y-4">
          <h2 className="text-2xl">Your consent</h2>

          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={form.consentPublic}
              onChange={(e) => update('consentPublic', e.target.checked)}
              className="mt-1"
            />
            <span className="text-sm">
              I understand that my display name, city, bio, and socials will be <strong>publicly visible</strong> on the map to anyone who visits the site.
            </span>
          </label>

          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={form.consentPrivacy}
              onChange={(e) => update('consentPrivacy', e.target.checked)}
              className="mt-1"
            />
            <span className="text-sm">
              I have read and accept the <Link href="/legal/privacy" target="_blank" className="text-brand-red underline">Privacy Policy</Link>.
            </span>
          </label>

          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={form.consentTerms}
              onChange={(e) => update('consentTerms', e.target.checked)}
              className="mt-1"
            />
            <span className="text-sm">
              I have read and accept the <Link href="/legal/terms" target="_blank" className="text-brand-red underline">Terms of Service</Link>.
            </span>
          </label>
        </div>

        {result && !result.ok && (
          <div className="border-2 border-brand-red bg-brand-red/10 p-4 text-sm">{result.message}</div>
        )}

        <button type="submit" className="btn-primary w-full" disabled={submitting}>
          {submitting ? 'Submitting…' : 'Submit My Entry'}
        </button>

        <p className="text-xs text-navy/60 text-center">
          You can edit or delete your entry anytime. Just visit the <Link href="/profile" className="underline">My Entry</Link> page and we&apos;ll send a magic link.
        </p>
      </form>
    </div>
  );
}
