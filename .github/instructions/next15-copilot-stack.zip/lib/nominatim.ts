import 'server-only'
import { createServiceClient } from './supabase/server'

const USER_AGENT = 'your-app/1.0 (contact@yourdomain.com)' // TODO: replace with your app name and contact email
const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search'

let lastRequestAt = 0
async function rateLimit() {
  const now = Date.now()
  const wait = 1100 - (now - lastRequestAt)
  if (wait > 0) await new Promise((r) => setTimeout(r, wait))
  lastRequestAt = Date.now()
}

export type GeocodeResult = {
  lat: number
  lon: number
  display_name: string
  source: 'cache' | 'nominatim'
  raw: unknown
}

export async function geocodeCity(query: string): Promise<GeocodeResult | null> {
  const q = query.trim().toLowerCase()
  if (!q) return null

  const supabase = createServiceClient()

  // 1. Check cache
  const { data: cached } = await supabase
    .from('geocode_cache')
    .select('lat, lon, result, cached_at')
    .eq('query', q)
    .maybeSingle()

  if (cached) {
    return {
      lat: Number(cached.lat),
      lon: Number(cached.lon),
      display_name: (cached.result as any)?.display_name ?? q,
      source: 'cache',
      raw: cached.result,
    }
  }

  // 2. Rate limit and fetch
  await rateLimit()
  const url = new URL(NOMINATIM_URL)
  url.searchParams.set('q', query)
  url.searchParams.set('format', 'jsonv2')
  url.searchParams.set('limit', '1')
  url.searchParams.set('addressdetails', '0')

  const res = await fetch(url.toString(), {
    headers: {
      'User-Agent': USER_AGENT,
      Accept: 'application/json',
    },
    cache: 'no-store',
  })

  if (!res.ok) return null
  const json = await res.json()
  const first = json?.[0]
  if (!first) return null

  const result = {
    lat: parseFloat(first.lat),
    lon: parseFloat(first.lon),
    display_name: first.display_name,
    source: 'nominatim' as const,
    raw: first,
  }

  // 3. Write cache (best-effort)
  await supabase.from('geocode_cache').upsert({
    query: q,
    lat: result.lat,
    lon: result.lon,
    result: first,
    cached_at: new Date().toISOString(),
  })

  return result
}
