import 'server-only'
import { Resend } from 'resend'
import type { ReactElement } from 'react'

const apiKey = process.env.RESEND_API_KEY
if (!apiKey) throw new Error('RESEND_API_KEY is not set')

export const resend = new Resend(apiKey)

export type EmailResult =
  | { success: true; id: string }
  | { success: false; error: string }

export async function sendTransactionalEmail(params: {
  to: string | string[]
  subject: string
  react: ReactElement
  from?: string
}): Promise<EmailResult> {
  try {
    const { data, error } = await resend.emails.send({
      from: params.from ?? 'App <onboarding@resend.dev>',
      to: Array.isArray(params.to) ? params.to : [params.to],
      subject: params.subject,
      react: params.react,
    })
    if (error) return { success: false, error: error.message }
    return { success: true, id: data!.id }
  } catch (e: any) {
    return { success: false, error: e?.message ?? 'Unknown error' }
  }
}
