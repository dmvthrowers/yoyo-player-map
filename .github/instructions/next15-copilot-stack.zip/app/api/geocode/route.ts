import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { geocodeCity } from '@/lib/nominatim'

const schema = z.object({ q: z.string().min(2).max(100) })

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q') ?? ''
  const parsed = schema.safeParse({ q })
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid query' }, { status: 400 })
  }
  const result = await geocodeCity(parsed.data.q)
  if (!result) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(result)
}
